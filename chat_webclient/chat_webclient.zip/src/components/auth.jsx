import React from 'react';

const auth = () => {
  return <div>Auth</div>;
};

export default auth;
