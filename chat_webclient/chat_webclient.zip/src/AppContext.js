import React from 'react';

export const OrganizationIdContext = React.createContext();
export const OrganizationsContext = React.createContext();
